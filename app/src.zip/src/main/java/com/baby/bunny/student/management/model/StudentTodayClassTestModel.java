package com.baby.bunny.student.management.model;

public class StudentTodayClassTestModel {

    String description;




    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
