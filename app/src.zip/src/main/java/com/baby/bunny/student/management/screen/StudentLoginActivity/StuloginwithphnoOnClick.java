package com.baby.bunny.student.management.screen.StudentLoginActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.baby.bunny.student.management.R;

public class StuloginwithphnoOnClick  implements View.OnClickListener {
    StudentLoginActivity stuloginwithphno;
    StuloginwithphnoViewBind stuloginwithphnoViewBind;

    public StuloginwithphnoOnClick(StudentLoginActivity stuloginwithphno, StuloginwithphnoViewBind stuloginwithphnoViewBind) {
        this.stuloginwithphno = stuloginwithphno;
        this.stuloginwithphnoViewBind = stuloginwithphnoViewBind;

        setonclicklistner();
    }

    // set click listner.
    private void setonclicklistner() {
        stuloginwithphnoViewBind.tvsubmitid.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvsubmmitid: {
                if (isConnected()) {
                   stuloginwithphno.loadsubmit();

                } else {

                    Toast.makeText(stuloginwithphno, "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }

        }
    }

    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) stuloginwithphno.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }

}



















