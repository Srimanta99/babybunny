package com.baby.bunny.student.management.utils;

public class ApplicationConstant {
    public  static  int SPLASH_DISPLAY_LENGTH=2000;

    public static String url="http://babybunny.in/babybunny/index.php/App/student/";
    public static String loginwithphnourl=url+"usercheck";
    public static String studentotpurl=url+"getotp";
    public static String studentOTP_Passwordurl=url+"login";
}
